-- Corre SOLO esto en tu proyecto (ya tienes las tablas creadas, no hace falta
-- correr schema.sql de nuevo). Ve a SQL Editor > New query, pega esto y Run.

grant usage on schema public to authenticated;
grant select, insert, update, delete on table public.ramos to authenticated;
grant select, insert, update, delete on table public.sesiones to authenticated;
